class Secrets {
  // Add your Google Maps API Key here
  static const API_KEY = 'AIzaSyBXNx7LSH5pFxR2BFJBfe2ZA6oPSnqumeM';
}