class Company {

  final String id;
  final String name;
  final String image;

  Company({
    this.id,
    this.name,
    this.image
  });

}